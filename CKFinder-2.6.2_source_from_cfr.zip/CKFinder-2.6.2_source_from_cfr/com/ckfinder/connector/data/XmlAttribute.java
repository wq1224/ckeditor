/*
 * Decompiled with CFR 0_115.
 */
package com.ckfinder.connector.data;

public class XmlAttribute {
    private String key;
    private String value;

    public XmlAttribute(String key1, String value1) {
        this.key = key1;
        this.value = value1;
    }

    public String getKey() {
        return this.key;
    }

    public void setKey(String key1) {
        this.key = key1;
    }

    public String getValue() {
        return this.value;
    }

    public void setValue(String value1) {
        this.value = value1;
    }
}

