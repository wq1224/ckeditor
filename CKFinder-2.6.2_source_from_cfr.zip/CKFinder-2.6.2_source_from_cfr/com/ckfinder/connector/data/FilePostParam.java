/*
 * Decompiled with CFR 0_115.
 */
package com.ckfinder.connector.data;

public class FilePostParam {
    private String folder;
    private String name;
    private String options;
    private String type;

    public final String getFolder() {
        return this.folder;
    }

    public final void setFolder(String folder) {
        this.folder = folder;
    }

    public final String getName() {
        return this.name;
    }

    public final void setName(String name) {
        this.name = name;
    }

    public final String getOptions() {
        return this.options;
    }

    public final void setOptions(String options) {
        this.options = options;
    }

    public final String getType() {
        return this.type;
    }

    public final void setType(String type) {
        this.type = type;
    }
}

