/*
 * Decompiled with CFR 0_115.
 */
package com.ckfinder.connector.data;

public class PluginParam {
    private String name;
    private String value;

    public final String getName() {
        return this.name;
    }

    public final void setName(String name) {
        this.name = name;
    }

    public final String getValue() {
        return this.value;
    }

    public final void setValue(String value) {
        this.value = value;
    }
}

