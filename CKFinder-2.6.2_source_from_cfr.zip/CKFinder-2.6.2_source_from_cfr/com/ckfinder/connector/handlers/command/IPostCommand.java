/*
 * Decompiled with CFR 0_115.
 */
package com.ckfinder.connector.handlers.command;

public interface IPostCommand {
}

